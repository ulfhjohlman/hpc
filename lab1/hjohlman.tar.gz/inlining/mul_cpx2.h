#ifndef mul_cpx2_h
#define mul_cpx2_h

void mul_cpx2( double * a_re, double * a_im, double * b_re, double * b_im, double * c_re, double * c_im);

#endif
